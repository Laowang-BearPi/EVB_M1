﻿namespace NADemo
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAppid = new System.Windows.Forms.TextBox();
            this.txtAppPwd = new System.Windows.Forms.TextBox();
            this.btnGetToken = new System.Windows.Forms.Button();
            this.txtToken = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPltIP = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.btnRegDevice = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txtVerifyCode = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDeviceID = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtPSK = new System.Windows.Forms.TextBox();
            this.cbhttp = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtMid = new System.Windows.Forms.TextBox();
            this.txtDModel = new System.Windows.Forms.TextBox();
            this.btnModifyDev = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txtModifyResult = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtCallbackURL = new System.Windows.Forms.TextBox();
            this.cbNotifyType = new System.Windows.Forms.ComboBox();
            this.btnSubcribe = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.txtSubResult = new System.Windows.Forms.TextBox();
            this.btnQueryHistoryData = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtHDCount = new System.Windows.Forms.TextBox();
            this.txtHDPageNo = new System.Windows.Forms.TextBox();
            this.txtHDPageSize = new System.Windows.Forms.TextBox();
            this.dgvHisData = new System.Windows.Forms.DataGridView();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.btnSendCommand = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.lbCmdParas = new System.Windows.Forms.ListBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.cbIsParaNum = new System.Windows.Forms.CheckBox();
            this.btnAddPara = new System.Windows.Forms.Button();
            this.btnDelPara = new System.Windows.Forms.Button();
            this.txtParaName = new System.Windows.Forms.TextBox();
            this.txtParaValue = new System.Windows.Forms.TextBox();
            this.txtSendCMDServiceID = new System.Windows.Forms.TextBox();
            this.txtCmdID = new System.Windows.Forms.TextBox();
            this.txtCmdCallbackURL = new System.Windows.Forms.TextBox();
            this.txtSendCmdResult = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtSendCmdDevID = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.txtModDevID = new System.Windows.Forms.TextBox();
            this.txtHDDevId = new System.Windows.Forms.TextBox();
            this.txtHDServiceID = new System.Windows.Forms.TextBox();
            this.txtHDQueryPageNo = new System.Windows.Forms.TextBox();
            this.txtHDQueryPageSize = new System.Windows.Forms.TextBox();
            this.dtpHDQueryStart = new System.Windows.Forms.DateTimePicker();
            this.dtpHDQueryEnd = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtCertPwd = new System.Windows.Forms.TextBox();
            this.btnSetCert = new System.Windows.Forms.Button();
            this.txtCertFile = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHisData)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtAppid
            // 
            this.txtAppid.Location = new System.Drawing.Point(439, 14);
            this.txtAppid.Name = "txtAppid";
            this.txtAppid.Size = new System.Drawing.Size(157, 21);
            this.txtAppid.TabIndex = 0;
            // 
            // txtAppPwd
            // 
            this.txtAppPwd.Location = new System.Drawing.Point(659, 14);
            this.txtAppPwd.Name = "txtAppPwd";
            this.txtAppPwd.Size = new System.Drawing.Size(152, 21);
            this.txtAppPwd.TabIndex = 0;
            // 
            // btnGetToken
            // 
            this.btnGetToken.Location = new System.Drawing.Point(735, 48);
            this.btnGetToken.Name = "btnGetToken";
            this.btnGetToken.Size = new System.Drawing.Size(75, 23);
            this.btnGetToken.TabIndex = 1;
            this.btnGetToken.Text = "获取Token";
            this.btnGetToken.UseVisualStyleBackColor = true;
            this.btnGetToken.Click += new System.EventHandler(this.btnGetToken_Click);
            // 
            // txtToken
            // 
            this.txtToken.Location = new System.Drawing.Point(531, 48);
            this.txtToken.Name = "txtToken";
            this.txtToken.Size = new System.Drawing.Size(147, 21);
            this.txtToken.TabIndex = 2;
            this.txtToken.Text = "点击获取Token的结果";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(398, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "appid";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(612, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "appkey";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(466, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "返回token";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "IP";
            // 
            // txtPltIP
            // 
            this.txtPltIP.Location = new System.Drawing.Point(59, 11);
            this.txtPltIP.Name = "txtPltIP";
            this.txtPltIP.Size = new System.Drawing.Size(196, 21);
            this.txtPltIP.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(289, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "Port";
            // 
            // txtPort
            // 
            this.txtPort.Location = new System.Drawing.Point(324, 14);
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(70, 21);
            this.txtPort.TabIndex = 9;
            this.txtPort.Text = "8743";
            // 
            // btnRegDevice
            // 
            this.btnRegDevice.Location = new System.Drawing.Point(736, 12);
            this.btnRegDevice.Name = "btnRegDevice";
            this.btnRegDevice.Size = new System.Drawing.Size(75, 23);
            this.btnRegDevice.TabIndex = 10;
            this.btnRegDevice.Text = "注册设备";
            this.btnRegDevice.UseVisualStyleBackColor = true;
            this.btnRegDevice.Click += new System.EventHandler(this.btnRegDevice_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 12);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 6;
            this.label6.Text = "VerifyCode";
            // 
            // txtVerifyCode
            // 
            this.txtVerifyCode.Location = new System.Drawing.Point(98, 9);
            this.txtVerifyCode.Name = "txtVerifyCode";
            this.txtVerifyCode.Size = new System.Drawing.Size(113, 21);
            this.txtVerifyCode.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(226, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "返回DeviceID";
            // 
            // txtDeviceID
            // 
            this.txtDeviceID.Location = new System.Drawing.Point(309, 12);
            this.txtDeviceID.Name = "txtDeviceID";
            this.txtDeviceID.Size = new System.Drawing.Size(174, 21);
            this.txtDeviceID.TabIndex = 12;
            this.txtDeviceID.Text = "点击注册设备的结果";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(489, 17);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 12);
            this.label8.TabIndex = 6;
            this.label8.Text = "返回PSK";
            // 
            // txtPSK
            // 
            this.txtPSK.Location = new System.Drawing.Point(538, 14);
            this.txtPSK.Name = "txtPSK";
            this.txtPSK.Size = new System.Drawing.Size(174, 21);
            this.txtPSK.TabIndex = 12;
            this.txtPSK.Text = "点击注册设备的结果";
            // 
            // cbhttp
            // 
            this.cbhttp.AutoSize = true;
            this.cbhttp.Location = new System.Drawing.Point(681, 54);
            this.cbhttp.Name = "cbhttp";
            this.cbhttp.Size = new System.Drawing.Size(48, 16);
            this.cbhttp.TabIndex = 13;
            this.cbhttp.Text = "HTTP";
            this.cbhttp.UseVisualStyleBackColor = true;
            this.cbhttp.CheckedChanged += new System.EventHandler(this.cbhttp_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(219, 52);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 6;
            this.label9.Text = "厂商ID";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(375, 55);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 6;
            this.label10.Text = "设备型号";
            // 
            // txtMid
            // 
            this.txtMid.Location = new System.Drawing.Point(266, 46);
            this.txtMid.Name = "txtMid";
            this.txtMid.Size = new System.Drawing.Size(113, 21);
            this.txtMid.TabIndex = 11;
            // 
            // txtDModel
            // 
            this.txtDModel.Location = new System.Drawing.Point(427, 52);
            this.txtDModel.Name = "txtDModel";
            this.txtDModel.Size = new System.Drawing.Size(113, 21);
            this.txtDModel.TabIndex = 11;
            // 
            // btnModifyDev
            // 
            this.btnModifyDev.Location = new System.Drawing.Point(736, 50);
            this.btnModifyDev.Name = "btnModifyDev";
            this.btnModifyDev.Size = new System.Drawing.Size(75, 23);
            this.btnModifyDev.TabIndex = 14;
            this.btnModifyDev.Text = "修改设备信息";
            this.btnModifyDev.UseVisualStyleBackColor = true;
            this.btnModifyDev.Click += new System.EventHandler(this.btnModifyDev_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(544, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 6;
            this.label11.Text = "返回结果";
            // 
            // txtModifyResult
            // 
            this.txtModifyResult.Location = new System.Drawing.Point(614, 55);
            this.txtModifyResult.Name = "txtModifyResult";
            this.txtModifyResult.Size = new System.Drawing.Size(87, 21);
            this.txtModifyResult.TabIndex = 11;
            this.txtModifyResult.Text = "修改设备结果";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(11, 95);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 15;
            this.label12.Text = "通知类型";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(15, 133);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(113, 12);
            this.label13.TabIndex = 15;
            this.label13.Text = "回调URL,必须带端口";
            // 
            // txtCallbackURL
            // 
            this.txtCallbackURL.Location = new System.Drawing.Point(151, 130);
            this.txtCallbackURL.Name = "txtCallbackURL";
            this.txtCallbackURL.Size = new System.Drawing.Size(531, 21);
            this.txtCallbackURL.TabIndex = 16;
            this.txtCallbackURL.Text = "https://serverIp.or.domainName:443/pushserver";
            // 
            // cbNotifyType
            // 
            this.cbNotifyType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbNotifyType.FormattingEnabled = true;
            this.cbNotifyType.Items.AddRange(new object[] {
            "deviceAdded",
            "deviceInfoChanged",
            "deviceDataChanged",
            "deviceDeleted",
            "deviceEvent",
            "messageConfirm",
            "commandRsp",
            "serviceInfoChanged",
            "ruleEvent",
            "bindDevice",
            "deviceDatasChanged"});
            this.cbNotifyType.Location = new System.Drawing.Point(81, 92);
            this.cbNotifyType.Name = "cbNotifyType";
            this.cbNotifyType.Size = new System.Drawing.Size(121, 20);
            this.cbNotifyType.TabIndex = 17;
            // 
            // btnSubcribe
            // 
            this.btnSubcribe.Location = new System.Drawing.Point(737, 128);
            this.btnSubcribe.Name = "btnSubcribe";
            this.btnSubcribe.Size = new System.Drawing.Size(94, 23);
            this.btnSubcribe.TabIndex = 18;
            this.btnSubcribe.Text = "订阅消息通知";
            this.btnSubcribe.UseVisualStyleBackColor = true;
            this.btnSubcribe.Click += new System.EventHandler(this.btnSubcribe_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(226, 100);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 6;
            this.label14.Text = "返回结果";
            // 
            // txtSubResult
            // 
            this.txtSubResult.Location = new System.Drawing.Point(292, 95);
            this.txtSubResult.Name = "txtSubResult";
            this.txtSubResult.Size = new System.Drawing.Size(174, 21);
            this.txtSubResult.TabIndex = 11;
            this.txtSubResult.Text = "点击订阅通知的结果";
            // 
            // btnQueryHistoryData
            // 
            this.btnQueryHistoryData.Location = new System.Drawing.Point(538, 47);
            this.btnQueryHistoryData.Name = "btnQueryHistoryData";
            this.btnQueryHistoryData.Size = new System.Drawing.Size(75, 23);
            this.btnQueryHistoryData.TabIndex = 19;
            this.btnQueryHistoryData.Text = "查询数据";
            this.btnQueryHistoryData.UseVisualStyleBackColor = true;
            this.btnQueryHistoryData.Click += new System.EventHandler(this.btnQueryHistoryData_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(75, 53);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 12);
            this.label15.TabIndex = 20;
            this.label15.Text = "总记录数";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(260, 53);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 12);
            this.label16.TabIndex = 20;
            this.label16.Text = "第几页";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(367, 54);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 12);
            this.label17.TabIndex = 21;
            this.label17.Text = "每页记录数";
            // 
            // txtHDCount
            // 
            this.txtHDCount.Location = new System.Drawing.Point(138, 49);
            this.txtHDCount.Name = "txtHDCount";
            this.txtHDCount.Size = new System.Drawing.Size(113, 21);
            this.txtHDCount.TabIndex = 11;
            this.txtHDCount.Text = "查询结果";
            // 
            // txtHDPageNo
            // 
            this.txtHDPageNo.Location = new System.Drawing.Point(311, 49);
            this.txtHDPageNo.Name = "txtHDPageNo";
            this.txtHDPageNo.Size = new System.Drawing.Size(44, 21);
            this.txtHDPageNo.TabIndex = 22;
            this.txtHDPageNo.Text = "查询结果";
            // 
            // txtHDPageSize
            // 
            this.txtHDPageSize.Location = new System.Drawing.Point(438, 51);
            this.txtHDPageSize.Name = "txtHDPageSize";
            this.txtHDPageSize.Size = new System.Drawing.Size(68, 21);
            this.txtHDPageSize.TabIndex = 23;
            this.txtHDPageSize.Text = "查询结果";
            // 
            // dgvHisData
            // 
            this.dgvHisData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHisData.Location = new System.Drawing.Point(13, 76);
            this.dgvHisData.Name = "dgvHisData";
            this.dgvHisData.RowTemplate.Height = 23;
            this.dgvHisData.Size = new System.Drawing.Size(794, 114);
            this.dgvHisData.TabIndex = 24;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(11, 53);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 25;
            this.label18.Text = "结果返回";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(8, 18);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 25;
            this.label19.Text = "查询参数";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(75, 18);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 26;
            this.label20.Text = "DeviceID";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(254, 18);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(59, 12);
            this.label21.TabIndex = 27;
            this.label21.Text = "ServiceID";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(623, 18);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(53, 12);
            this.label22.TabIndex = 27;
            this.label22.Text = "开始时间";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(391, 18);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 12);
            this.label23.TabIndex = 20;
            this.label23.Text = "第几页";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(471, 18);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 12);
            this.label24.TabIndex = 21;
            this.label24.Text = "每页记录数";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(623, 53);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 12);
            this.label25.TabIndex = 27;
            this.label25.Text = "结束时间";
            // 
            // btnSendCommand
            // 
            this.btnSendCommand.Location = new System.Drawing.Point(583, 112);
            this.btnSendCommand.Name = "btnSendCommand";
            this.btnSendCommand.Size = new System.Drawing.Size(75, 23);
            this.btnSendCommand.TabIndex = 28;
            this.btnSendCommand.Text = "下发命令";
            this.btnSendCommand.UseVisualStyleBackColor = true;
            this.btnSendCommand.Click += new System.EventHandler(this.btnSendCommand_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(13, 16);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(53, 12);
            this.label26.TabIndex = 29;
            this.label26.Text = "DeviceID";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(16, 131);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(41, 12);
            this.label27.TabIndex = 30;
            this.label27.Text = "命令ID";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(16, 92);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(59, 12);
            this.label28.TabIndex = 31;
            this.label28.Text = "ServiceID";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(16, 59);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(47, 12);
            this.label29.TabIndex = 32;
            this.label29.Text = "回调URL";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(276, 11);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(53, 12);
            this.label30.TabIndex = 33;
            this.label30.Text = "命令参数";
            // 
            // lbCmdParas
            // 
            this.lbCmdParas.FormattingEnabled = true;
            this.lbCmdParas.ItemHeight = 12;
            this.lbCmdParas.Location = new System.Drawing.Point(335, 11);
            this.lbCmdParas.Name = "lbCmdParas";
            this.lbCmdParas.Size = new System.Drawing.Size(242, 124);
            this.lbCmdParas.TabIndex = 34;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(637, 16);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(41, 12);
            this.label31.TabIndex = 35;
            this.label31.Text = "参数名";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(637, 40);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(17, 12);
            this.label32.TabIndex = 36;
            this.label32.Text = "值";
            // 
            // cbIsParaNum
            // 
            this.cbIsParaNum.AutoSize = true;
            this.cbIsParaNum.Location = new System.Drawing.Point(684, 66);
            this.cbIsParaNum.Name = "cbIsParaNum";
            this.cbIsParaNum.Size = new System.Drawing.Size(60, 16);
            this.cbIsParaNum.TabIndex = 37;
            this.cbIsParaNum.Text = "是数字";
            this.cbIsParaNum.UseVisualStyleBackColor = true;
            // 
            // btnAddPara
            // 
            this.btnAddPara.Location = new System.Drawing.Point(583, 16);
            this.btnAddPara.Name = "btnAddPara";
            this.btnAddPara.Size = new System.Drawing.Size(45, 23);
            this.btnAddPara.TabIndex = 38;
            this.btnAddPara.Text = "增加";
            this.btnAddPara.UseVisualStyleBackColor = true;
            this.btnAddPara.Click += new System.EventHandler(this.btnAddPara_Click);
            // 
            // btnDelPara
            // 
            this.btnDelPara.Location = new System.Drawing.Point(583, 59);
            this.btnDelPara.Name = "btnDelPara";
            this.btnDelPara.Size = new System.Drawing.Size(45, 23);
            this.btnDelPara.TabIndex = 39;
            this.btnDelPara.Text = "删除";
            this.btnDelPara.UseVisualStyleBackColor = true;
            this.btnDelPara.Click += new System.EventHandler(this.btnDelPara_Click);
            // 
            // txtParaName
            // 
            this.txtParaName.Location = new System.Drawing.Point(684, 13);
            this.txtParaName.Name = "txtParaName";
            this.txtParaName.Size = new System.Drawing.Size(113, 21);
            this.txtParaName.TabIndex = 40;
            // 
            // txtParaValue
            // 
            this.txtParaValue.Location = new System.Drawing.Point(684, 39);
            this.txtParaValue.Name = "txtParaValue";
            this.txtParaValue.Size = new System.Drawing.Size(113, 21);
            this.txtParaValue.TabIndex = 41;
            // 
            // txtSendCMDServiceID
            // 
            this.txtSendCMDServiceID.Location = new System.Drawing.Point(87, 89);
            this.txtSendCMDServiceID.Name = "txtSendCMDServiceID";
            this.txtSendCMDServiceID.Size = new System.Drawing.Size(96, 21);
            this.txtSendCMDServiceID.TabIndex = 42;
            // 
            // txtCmdID
            // 
            this.txtCmdID.Location = new System.Drawing.Point(87, 128);
            this.txtCmdID.Name = "txtCmdID";
            this.txtCmdID.Size = new System.Drawing.Size(96, 21);
            this.txtCmdID.TabIndex = 42;
            // 
            // txtCmdCallbackURL
            // 
            this.txtCmdCallbackURL.Location = new System.Drawing.Point(72, 56);
            this.txtCmdCallbackURL.Name = "txtCmdCallbackURL";
            this.txtCmdCallbackURL.Size = new System.Drawing.Size(198, 21);
            this.txtCmdCallbackURL.TabIndex = 43;
            // 
            // txtSendCmdResult
            // 
            this.txtSendCmdResult.Location = new System.Drawing.Point(768, 114);
            this.txtSendCmdResult.Name = "txtSendCmdResult";
            this.txtSendCmdResult.Size = new System.Drawing.Size(47, 21);
            this.txtSendCmdResult.TabIndex = 45;
            this.txtSendCmdResult.Text = "下发结果";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(703, 119);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(53, 12);
            this.label33.TabIndex = 44;
            this.label33.Text = "返回结果";
            // 
            // txtSendCmdDevID
            // 
            this.txtSendCmdDevID.Location = new System.Drawing.Point(79, 16);
            this.txtSendCmdDevID.Name = "txtSendCmdDevID";
            this.txtSendCmdDevID.Size = new System.Drawing.Size(174, 21);
            this.txtSendCmdDevID.TabIndex = 46;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(12, 55);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(53, 12);
            this.label34.TabIndex = 6;
            this.label34.Text = "DeviceID";
            // 
            // txtModDevID
            // 
            this.txtModDevID.Location = new System.Drawing.Point(96, 46);
            this.txtModDevID.Name = "txtModDevID";
            this.txtModDevID.Size = new System.Drawing.Size(115, 21);
            this.txtModDevID.TabIndex = 12;
            // 
            // txtHDDevId
            // 
            this.txtHDDevId.Location = new System.Drawing.Point(138, 15);
            this.txtHDDevId.Name = "txtHDDevId";
            this.txtHDDevId.Size = new System.Drawing.Size(110, 21);
            this.txtHDDevId.TabIndex = 47;
            // 
            // txtHDServiceID
            // 
            this.txtHDServiceID.Location = new System.Drawing.Point(319, 15);
            this.txtHDServiceID.Name = "txtHDServiceID";
            this.txtHDServiceID.Size = new System.Drawing.Size(68, 21);
            this.txtHDServiceID.TabIndex = 48;
            // 
            // txtHDQueryPageNo
            // 
            this.txtHDQueryPageNo.Location = new System.Drawing.Point(436, 15);
            this.txtHDQueryPageNo.Name = "txtHDQueryPageNo";
            this.txtHDQueryPageNo.Size = new System.Drawing.Size(37, 21);
            this.txtHDQueryPageNo.TabIndex = 49;
            // 
            // txtHDQueryPageSize
            // 
            this.txtHDQueryPageSize.Location = new System.Drawing.Point(538, 15);
            this.txtHDQueryPageSize.Name = "txtHDQueryPageSize";
            this.txtHDQueryPageSize.Size = new System.Drawing.Size(37, 21);
            this.txtHDQueryPageSize.TabIndex = 50;
            // 
            // dtpHDQueryStart
            // 
            this.dtpHDQueryStart.Location = new System.Drawing.Point(682, 18);
            this.dtpHDQueryStart.Name = "dtpHDQueryStart";
            this.dtpHDQueryStart.Size = new System.Drawing.Size(144, 21);
            this.dtpHDQueryStart.TabIndex = 51;
            // 
            // dtpHDQueryEnd
            // 
            this.dtpHDQueryEnd.Location = new System.Drawing.Point(682, 45);
            this.dtpHDQueryEnd.Name = "dtpHDQueryEnd";
            this.dtpHDQueryEnd.Size = new System.Drawing.Size(144, 21);
            this.dtpHDQueryEnd.TabIndex = 52;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label36);
            this.groupBox1.Controls.Add(this.txtCertPwd);
            this.groupBox1.Controls.Add(this.btnSetCert);
            this.groupBox1.Controls.Add(this.txtCertFile);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.cbhttp);
            this.groupBox1.Controls.Add(this.txtPort);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtPltIP);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtToken);
            this.groupBox1.Controls.Add(this.btnGetToken);
            this.groupBox1.Controls.Add(this.txtAppPwd);
            this.groupBox1.Controls.Add(this.txtAppid);
            this.groupBox1.Location = new System.Drawing.Point(2, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(828, 84);
            this.groupBox1.TabIndex = 53;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "鉴权获取Token";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(212, 51);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(53, 12);
            this.label36.TabIndex = 18;
            this.label36.Text = "证书文件";
            // 
            // txtCertPwd
            // 
            this.txtCertPwd.Location = new System.Drawing.Point(68, 45);
            this.txtCertPwd.Name = "txtCertPwd";
            this.txtCertPwd.Size = new System.Drawing.Size(138, 21);
            this.txtCertPwd.TabIndex = 17;
            // 
            // btnSetCert
            // 
            this.btnSetCert.Location = new System.Drawing.Point(397, 47);
            this.btnSetCert.Name = "btnSetCert";
            this.btnSetCert.Size = new System.Drawing.Size(63, 23);
            this.btnSetCert.TabIndex = 16;
            this.btnSetCert.Text = "选择证书";
            this.btnSetCert.UseVisualStyleBackColor = true;
            this.btnSetCert.Click += new System.EventHandler(this.btnSetCert_Click);
            // 
            // txtCertFile
            // 
            this.txtCertFile.Location = new System.Drawing.Point(262, 48);
            this.txtCertFile.Name = "txtCertFile";
            this.txtCertFile.Size = new System.Drawing.Size(132, 21);
            this.txtCertFile.TabIndex = 15;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(6, 48);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(53, 12);
            this.label35.TabIndex = 14;
            this.label35.Text = "证书密码";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtSendCmdDevID);
            this.groupBox2.Controls.Add(this.txtSendCmdResult);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.txtCmdCallbackURL);
            this.groupBox2.Controls.Add(this.txtCmdID);
            this.groupBox2.Controls.Add(this.txtSendCMDServiceID);
            this.groupBox2.Controls.Add(this.txtParaValue);
            this.groupBox2.Controls.Add(this.txtParaName);
            this.groupBox2.Controls.Add(this.btnDelPara);
            this.groupBox2.Controls.Add(this.btnAddPara);
            this.groupBox2.Controls.Add(this.cbIsParaNum);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.lbCmdParas);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.btnSendCommand);
            this.groupBox2.Location = new System.Drawing.Point(2, 495);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(840, 159);
            this.groupBox2.TabIndex = 54;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "设备命令下发";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dtpHDQueryEnd);
            this.groupBox3.Controls.Add(this.dtpHDQueryStart);
            this.groupBox3.Controls.Add(this.txtHDQueryPageSize);
            this.groupBox3.Controls.Add(this.txtHDQueryPageNo);
            this.groupBox3.Controls.Add(this.txtHDServiceID);
            this.groupBox3.Controls.Add(this.txtHDDevId);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.dgvHisData);
            this.groupBox3.Controls.Add(this.txtHDPageSize);
            this.groupBox3.Controls.Add(this.txtHDPageNo);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.btnQueryHistoryData);
            this.groupBox3.Controls.Add(this.txtHDCount);
            this.groupBox3.Location = new System.Drawing.Point(6, 285);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(836, 204);
            this.groupBox3.TabIndex = 55;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "设备历史数据查询";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnSubcribe);
            this.groupBox4.Controls.Add(this.cbNotifyType);
            this.groupBox4.Controls.Add(this.txtCallbackURL);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.btnModifyDev);
            this.groupBox4.Controls.Add(this.txtPSK);
            this.groupBox4.Controls.Add(this.txtModDevID);
            this.groupBox4.Controls.Add(this.txtDeviceID);
            this.groupBox4.Controls.Add(this.txtSubResult);
            this.groupBox4.Controls.Add(this.txtModifyResult);
            this.groupBox4.Controls.Add(this.txtDModel);
            this.groupBox4.Controls.Add(this.txtMid);
            this.groupBox4.Controls.Add(this.txtVerifyCode);
            this.groupBox4.Controls.Add(this.btnRegDevice);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label34);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Location = new System.Drawing.Point(6, 105);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(840, 164);
            this.groupBox4.TabIndex = 56;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "设备注册修改和订阅通知";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(859, 659);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "s";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHisData)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtAppid;
        private System.Windows.Forms.TextBox txtAppPwd;
        private System.Windows.Forms.Button btnGetToken;
        private System.Windows.Forms.TextBox txtToken;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPltIP;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.Button btnRegDevice;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtVerifyCode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDeviceID;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtPSK;
        private System.Windows.Forms.CheckBox cbhttp;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtMid;
        private System.Windows.Forms.TextBox txtDModel;
        private System.Windows.Forms.Button btnModifyDev;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtModifyResult;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtCallbackURL;
        private System.Windows.Forms.ComboBox cbNotifyType;
        private System.Windows.Forms.Button btnSubcribe;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtSubResult;
        private System.Windows.Forms.Button btnQueryHistoryData;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtHDCount;
        private System.Windows.Forms.TextBox txtHDPageNo;
        private System.Windows.Forms.TextBox txtHDPageSize;
        private System.Windows.Forms.DataGridView dgvHisData;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button btnSendCommand;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ListBox lbCmdParas;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.CheckBox cbIsParaNum;
        private System.Windows.Forms.Button btnAddPara;
        private System.Windows.Forms.Button btnDelPara;
        private System.Windows.Forms.TextBox txtParaName;
        private System.Windows.Forms.TextBox txtParaValue;
        private System.Windows.Forms.TextBox txtSendCMDServiceID;
        private System.Windows.Forms.TextBox txtCmdID;
        private System.Windows.Forms.TextBox txtCmdCallbackURL;
        private System.Windows.Forms.TextBox txtSendCmdResult;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtSendCmdDevID;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtModDevID;
        private System.Windows.Forms.TextBox txtHDDevId;
        private System.Windows.Forms.TextBox txtHDServiceID;
        private System.Windows.Forms.TextBox txtHDQueryPageNo;
        private System.Windows.Forms.TextBox txtHDQueryPageSize;
        private System.Windows.Forms.DateTimePicker dtpHDQueryStart;
        private System.Windows.Forms.DateTimePicker dtpHDQueryEnd;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnSetCert;
        private System.Windows.Forms.TextBox txtCertFile;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtCertPwd;
    }
}

